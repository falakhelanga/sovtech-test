/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 393:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_datasource_rest_1 = __webpack_require__(830);
class StarWarsAPI extends apollo_datasource_rest_1.RESTDataSource {
    constructor() {
        super();
        this.baseURL = "https://swapi.dev/api/";
    }
    getPeople(page) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.get(`people/?page=${page}`);
        });
    }
    getPersonById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.get(`people/${id}/`);
        });
    }
    getPerson(search) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.get(`people/?search=${search}`);
        });
    }
    getHomeWorld(url) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.get(url);
        });
    }
}
exports.default = StarWarsAPI;


/***/ }),

/***/ 494:
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const resolvers = {
    Query: {
        People: (_, { page }, { dataSources }) => __awaiter(void 0, void 0, void 0, function* () {
            return dataSources.starWarsAPI.getPeople(page);
        }),
        Person: (_, { id }, { dataSources }) => __awaiter(void 0, void 0, void 0, function* () {
            return dataSources.starWarsAPI.getPersonById(id);
        }),
        Search: (_, { search }, { dataSources }) => __awaiter(void 0, void 0, void 0, function* () {
            return dataSources.starWarsAPI.getPerson(search);
        }),
        Homeworld: (_, { url }, { dataSources }) => __awaiter(void 0, void 0, void 0, function* () {
            return dataSources.starWarsAPI.getHomeWorld(url);
        }),
    },
};
exports.default = resolvers;


/***/ }),

/***/ 799:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_server_lambda_1 = __webpack_require__(680);
const typeDefs = apollo_server_lambda_1.gql `
  type Homeworld {
    name: String
    rotation_period: String
    orbital_period: String
    diameter: String
    climate: String
    gravity: String
    terrain: String
    surface_water: String
    population: String
    residents: [String]
    films: [String]
  }

  type Person {
    name: String
    height: String
    mass: String
    gender: String
    homeworld: String
  }

  type People {
    next: String
    previous: String
    results: [Person]!
  }

  type Query {
    People(page: String): People!
    Person(id: String): Person!
    Search(search: String): People!
    Homeworld(url: String): Homeworld!
  }
`;
exports.default = typeDefs;


/***/ }),

/***/ 607:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const index_1 = __importDefault(__webpack_require__(393));
const typedefs_1 = __importDefault(__webpack_require__(799));
const resolvers_1 = __importDefault(__webpack_require__(494));
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    typeDefs: typedefs_1.default,
    resolvers: resolvers_1.default,
    dataSources: () => {
        return {
            starWarsAPI: new index_1.default(),
        };
    },
});
exports.graphqlHandler = apolloServer.createHandler({
    cors: {
        origin: "*",
        credentials: true,
    },
});


/***/ }),

/***/ 830:
/***/ ((module) => {

module.exports = require("apollo-datasource-rest");

/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(607);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2luZGV4LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBwb2xsby1zZXJ2ZXJsZXNzLy4vc3JjL2RhdGFzb3VyY2VzL2luZGV4LnRzIiwid2VicGFjazovL2FwcG9sbG8tc2VydmVybGVzcy8uL3NyYy9ncmFwaFFsL3Jlc29sdmVycy50cyIsIndlYnBhY2s6Ly9hcHBvbGxvLXNlcnZlcmxlc3MvLi9zcmMvZ3JhcGhRbC90eXBlZGVmcy50cyIsIndlYnBhY2s6Ly9hcHBvbGxvLXNlcnZlcmxlc3MvLi9zcmMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vYXBwb2xsby1zZXJ2ZXJsZXNzL2V4dGVybmFsIFwiYXBvbGxvLWRhdGFzb3VyY2UtcmVzdFwiIiwid2VicGFjazovL2FwcG9sbG8tc2VydmVybGVzcy9leHRlcm5hbCBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIiLCJ3ZWJwYWNrOi8vYXBwb2xsby1zZXJ2ZXJsZXNzL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2FwcG9sbG8tc2VydmVybGVzcy93ZWJwYWNrL3N0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUkVTVERhdGFTb3VyY2UgfSBmcm9tIFwiYXBvbGxvLWRhdGFzb3VyY2UtcmVzdFwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU3RhcldhcnNBUEkgZXh0ZW5kcyBSRVNURGF0YVNvdXJjZSB7XHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICBzdXBlcigpO1xyXG4gICAgdGhpcy5iYXNlVVJMID0gXCJodHRwczovL3N3YXBpLmRldi9hcGkvXCI7XHJcbiAgfVxyXG5cclxuICAvLyBnZXQgYWxsIHBlYXBsZVxyXG4gIGFzeW5jIGdldFBlb3BsZShwYWdlOiBzdHJpbmcpIHtcclxuICAgIHJldHVybiBhd2FpdCB0aGlzLmdldChgcGVvcGxlLz9wYWdlPSR7cGFnZX1gKTtcclxuICB9XHJcblxyXG4gIC8vIGdldCBwZXJzb24gYnkgSURcclxuICBhc3luYyBnZXRQZXJzb25CeUlkKGlkOiBzdHJpbmcpIHtcclxuICAgIHJldHVybiBhd2FpdCB0aGlzLmdldChgcGVvcGxlLyR7aWR9L2ApO1xyXG4gIH1cclxuXHJcbiAgLy8gZ2V0IHBhcnRpY3VsYXIgcGVvcGxlIGJ5IHF1ZXJ5LXBhcmFtZXRlciA9IHNlYXJjaFxyXG4gIGFzeW5jIGdldFBlcnNvbihzZWFyY2g6IHN0cmluZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuZ2V0KGBwZW9wbGUvP3NlYXJjaD0ke3NlYXJjaH1gKTtcclxuICB9XHJcblxyXG4gIC8vIGdldCBob21ld29ybGQgZm9yIHBhcnRpY3VsYXIgcGVyc29uXHJcbiAgYXN5bmMgZ2V0SG9tZVdvcmxkKHVybDogc3RyaW5nKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5nZXQodXJsKTtcclxuICB9XHJcbn1cclxuIiwiY29uc3QgcmVzb2x2ZXJzID0ge1xyXG4gIFF1ZXJ5OiB7XHJcbiAgICAvLyB0aGlzIHJlc29sdmVyIGlzIGZldGNoaW5nIGFsbCBwZW9wbGUgZnJvbSAgc3RhcndhcnNBUElcclxuICAgIFBlb3BsZTogYXN5bmMgKF86IGFueSwgeyBwYWdlIH06IGFueSwgeyBkYXRhU291cmNlcyB9OiBhbnkpID0+IHtcclxuICAgICAgcmV0dXJuIGRhdGFTb3VyY2VzLnN0YXJXYXJzQVBJLmdldFBlb3BsZShwYWdlKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdGhpcyByZXNvbHZlciBpcyBmZXRjaGluZyBvbmUgcGVyc29uIGZyb20gIHN0YXJ3YXJzQVBJXHJcbiAgICBQZXJzb246IGFzeW5jIChfOiBhbnksIHsgaWQgfTogYW55LCB7IGRhdGFTb3VyY2VzIH06IGFueSkgPT4ge1xyXG4gICAgICByZXR1cm4gZGF0YVNvdXJjZXMuc3RhcldhcnNBUEkuZ2V0UGVyc29uQnlJZChpZCk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHRoaXMgcmVzb2x2ZXIgaXMgZmV0Y2hpbmcgYWxsIHBlYXBsZSB3aXRoIGEgbmFtZSBtYXRjaGluZyBxdWVyeS1zdHJpbmcgPSBzZWFyY2hcclxuICAgIFNlYXJjaDogYXN5bmMgKF86IGFueSwgeyBzZWFyY2ggfTogYW55LCB7IGRhdGFTb3VyY2VzIH06IGFueSkgPT4ge1xyXG4gICAgICByZXR1cm4gZGF0YVNvdXJjZXMuc3RhcldhcnNBUEkuZ2V0UGVyc29uKHNlYXJjaCk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHRoaXMgcmVzb2x2ZXIgaXMgZmV0Y2hpbmcgYWxsIHBlYXBsZSB3aXRoIGEgbmFtZSBtYXRjaGluZyBxdWVyeS1zdHJpbmcgPSBzZWFyY2hcclxuICAgIEhvbWV3b3JsZDogYXN5bmMgKF86IGFueSwgeyB1cmwgfTogYW55LCB7IGRhdGFTb3VyY2VzIH06IGFueSkgPT4ge1xyXG4gICAgICByZXR1cm4gZGF0YVNvdXJjZXMuc3RhcldhcnNBUEkuZ2V0SG9tZVdvcmxkKHVybCk7XHJcbiAgICB9LFxyXG4gIH0sXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCByZXNvbHZlcnM7XHJcbiIsImltcG9ydCB7IGdxbCB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xyXG5cclxuY29uc3QgdHlwZURlZnMgPSBncWxgXHJcbiAgdHlwZSBIb21ld29ybGQge1xyXG4gICAgbmFtZTogU3RyaW5nXHJcbiAgICByb3RhdGlvbl9wZXJpb2Q6IFN0cmluZ1xyXG4gICAgb3JiaXRhbF9wZXJpb2Q6IFN0cmluZ1xyXG4gICAgZGlhbWV0ZXI6IFN0cmluZ1xyXG4gICAgY2xpbWF0ZTogU3RyaW5nXHJcbiAgICBncmF2aXR5OiBTdHJpbmdcclxuICAgIHRlcnJhaW46IFN0cmluZ1xyXG4gICAgc3VyZmFjZV93YXRlcjogU3RyaW5nXHJcbiAgICBwb3B1bGF0aW9uOiBTdHJpbmdcclxuICAgIHJlc2lkZW50czogW1N0cmluZ11cclxuICAgIGZpbG1zOiBbU3RyaW5nXVxyXG4gIH1cclxuXHJcbiAgdHlwZSBQZXJzb24ge1xyXG4gICAgbmFtZTogU3RyaW5nXHJcbiAgICBoZWlnaHQ6IFN0cmluZ1xyXG4gICAgbWFzczogU3RyaW5nXHJcbiAgICBnZW5kZXI6IFN0cmluZ1xyXG4gICAgaG9tZXdvcmxkOiBTdHJpbmdcclxuICB9XHJcblxyXG4gIHR5cGUgUGVvcGxlIHtcclxuICAgIG5leHQ6IFN0cmluZ1xyXG4gICAgcHJldmlvdXM6IFN0cmluZ1xyXG4gICAgcmVzdWx0czogW1BlcnNvbl0hXHJcbiAgfVxyXG5cclxuICB0eXBlIFF1ZXJ5IHtcclxuICAgIFBlb3BsZShwYWdlOiBTdHJpbmcpOiBQZW9wbGUhXHJcbiAgICBQZXJzb24oaWQ6IFN0cmluZyk6IFBlcnNvbiFcclxuICAgIFNlYXJjaChzZWFyY2g6IFN0cmluZyk6IFBlb3BsZSFcclxuICAgIEhvbWV3b3JsZCh1cmw6IFN0cmluZyk6IEhvbWV3b3JsZCFcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB0eXBlRGVmcztcclxuIiwiaW1wb3J0IHsgQXBvbGxvU2VydmVyIH0gZnJvbSBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCI7XHJcbmltcG9ydCBTdGFyV2Fyc0FQSSBmcm9tIFwiLi9kYXRhc291cmNlcy9pbmRleFwiO1xyXG5pbXBvcnQgdHlwZURlZnMgZnJvbSBcIi4vZ3JhcGhRbC90eXBlZGVmc1wiO1xyXG5pbXBvcnQgcmVzb2x2ZXJzIGZyb20gXCIuL2dyYXBoUWwvcmVzb2x2ZXJzXCI7XHJcblxyXG5jb25zdCBhcG9sbG9TZXJ2ZXIgPSBuZXcgQXBvbGxvU2VydmVyKHtcclxuICB0eXBlRGVmcyxcclxuICByZXNvbHZlcnMsXHJcbiAgZGF0YVNvdXJjZXM6ICgpID0+IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN0YXJXYXJzQVBJOiBuZXcgU3RhcldhcnNBUEkoKSxcclxuICAgIH07XHJcbiAgfSxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgZ3JhcGhxbEhhbmRsZXIgPSBhcG9sbG9TZXJ2ZXIuY3JlYXRlSGFuZGxlcih7XHJcbiAgY29yczoge1xyXG4gICAgb3JpZ2luOiBcIipcIixcclxuICAgIGNyZWRlbnRpYWxzOiB0cnVlLFxyXG4gIH0sXHJcbn0pO1xyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tZGF0YXNvdXJjZS1yZXN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIpOyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGlzIHJlZmVyZW5jZWQgYnkgb3RoZXIgbW9kdWxlcyBzbyBpdCBjYW4ndCBiZSBpbmxpbmVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18oNjA3KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7O0FBQ0E7QUFDQTtBQUFBO0FBR0E7O0FBQ0E7QUFDQTtBQUFBO0FBR0E7O0FBQ0E7QUFDQTtBQUFBO0FBR0E7O0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUF6QkE7OztBOzs7Ozs7Ozs7Ozs7Ozs7O0FDRkE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7O0E7Ozs7Ozs7QUN4QkE7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQ0E7QUFFQTs7O0E7Ozs7Ozs7Ozs7O0FDdkNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QTs7Ozs7QUNwQkE7O0E7Ozs7O0FDQUE7O0E7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7O0EiLCJzb3VyY2VSb290IjoiIn0=